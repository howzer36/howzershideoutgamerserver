local consoleCommands = {
	'set MOBCAP to 4',
	'set MOBSLESSAGGRESSIVE to 1'
	}
	
customEventHooks.registerHandler("OnPlayerFinishLogin", function(eventStatus, pid)
	
for _, consoleCommand in ipairs(consoleCommands) do
		logicHandler.RunConsoleCommandOnPlayer(pid, consoleCommand)
	end
	end)